from check import CheckWin

def solve(filename):
    fh=open(filename,"r")
    lines=fh.readlines()
    task1=open("winner.csv","w")
    task2=open("tile.csv","w")
    task3=open("point.csv","w")
    dealer=lines[0].strip()
    dlr=0
    name=lines[1].strip().split(',')
    for i in range(4):
        if dealer == name[i]:
            dlr=i
    #0,1,2,3
    a=[]
    b=[]
    c=[]
    d=[]
    #0 ?
    abcd=[a,b,c,d]
    lines2=lines[2:]
    for i in lines2:
        L=i.strip().split(',')
        for j in range(4):
            if len(L[j])>0:
                abcd[j].append(L[j])
    ka = 0
    kb = 0
    kc = 0
    kd = 0
    k = [ka, kb, kc, kd]
    win=[0,0,0,0]
    def getCard(i):
        ret = abcd[i][k[i]]
        k[i] += 1
        return ret
    x=0
    y=[]
    while k[0]<len(a):
        A = []
        B = []
        C = []
        D = []
        ABCD = [A, B, C, D]
        for i in range(13):
            for j in range(4):
                ABCD[j].append(getCard(j))
        total = 13 * 4
        sav=dlr
        x+=1
        while total < 136:
            total += 1
            p=getCard(dlr)
            ABCD[dlr].append(p)
            F = CheckWin(ABCD[dlr])
            if F == True:
                y.append(p)
                break
            else:
                ABCD[dlr].remove(getCard(dlr))
                dlr = (dlr + 1) % 4

        if F == True:
            print(name[dlr],file=task1)
            win[dlr]=win[dlr]+1
        else:
            print("Draw",file=task1)
        dlr=(sav+1)%4
    print('',file=task1)
    for i in range(4):
        print("{0},{1:.2%}".format(name[i],win[i]/x),file=task1)#python格式串
    z=[]
    for i in y:
        z.append((-y.count(i),i))
    z=list(set(z))
    list.sort(z)
    for i in z:
        print("{0},{1:.2%}".format(i[1],-i[0]/x),file=task2)


#solve("test.csv")
